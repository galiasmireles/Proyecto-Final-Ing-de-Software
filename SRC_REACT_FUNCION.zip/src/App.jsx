import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import NavBar from './components/NavBar'
import DoctorConsults from './pages/DoctorConsults'
import EditConsult from './pages/EditConsults'
import RecipePDF from './pages/RecipePDF.jsx'

import './App.css'

function App() {

  const PatientsRegistered = [
    { id: 1, patient_name: "Ana Paola Loredo" },
    { id: 2, patient_name: "Carlos Ruiz" },
    { id: 3, patient_name: "Roberto Gomez" },
    { id: 4, patient_name: "Galia Sejudo" }
  ];

  const [proxConsult, setProxConsult] = useState([
    {
      id: 1111,
      patient_name: "Ana Paola Loredo",
      date: "10/12/2025",
      hour: "10:00 AM",
      ubi: "Benavides Valle Alto",
      motive: ["Revisión general", "Dolor de cabeza leve"],
    },
    {
      id: 2222,
      patient_name: "Carlos Ruiz",
      date: "15/12/2025",
      hour: "04:00 PM",
      ubi: "Benavides Centro",
      motive: ["Entrega de resultados"],
    }
  ]);

  const [previousConsult, setPreviousConsult] = useState([
    {
      id: 3333,
      patient_name: "Ana Paola Loredo",
      date: "10/10/2025",
      hour: "09:00 AM",
      ubi: "Benavides Valle Alto",
      motive: ["Cuerpo cortado", "Gripe"],
      diagnostic: "Influenza",
      medical_studies: "- X-Ray Pulmones",
      followup: "SI",

      receta: {
        paciente: "Ana Paola Loredo",
        date: "10/10/2025",
        hour: "09:00 AM",
        medicamentos: [
          {
            medicamento: "Paracetamol",
            dosis: "500mg",
            presentacion: "Tabletas",
            frecuencia: "1 cada 8 horas por 5 días"
          }
        ]
      }
    },

    {
      id: 4444,
      patient_name: "Roberto Gomez",
      date: "01/09/2025",
      hour: "11:30 AM",
      ubi: "Benavides Sur",
      motive: ["Alergia estacional"],
      diagnostic: "Rinitis Alérgica",
      medical_studies: "N/A",
      followup: "NO",

      receta: {
        paciente: "Roberto Gomez",
        date: "01/09/2025",
        hour: "11:30 AM",
        medicamentos: [
          {
            medicamento: "Loratadina",
            dosis: "10mg",
            presentacion: "Tabletas",
            frecuencia: "1 diaria por 7 días"
          }
        ]
      }
    }
  ]);

  const addConsult = (consult) => {
    setProxConsult(prev => [...prev, consult]);
  };

  const updateConsult = (updated) => {
    setProxConsult(prev => prev.map(c => c.id === updated.id ? updated : c));
    setPreviousConsult(prev => prev.map(c => c.id === updated.id ? updated : c));
  };

  const deleteConsult = (id) => {
    setProxConsult(prev => prev.filter(c => c.id !== id));
    setPreviousConsult(prev => prev.filter(c => c.id !== id));
  };

  return (
    <>
      <NavBar />

      <main className="main-content">
        <Routes>

          <Route path="/"
            element={
              <DoctorConsults
                proxConsult={proxConsult}
                previousConsult={previousConsult}
                addConsult={addConsult}
                deleteConsult={deleteConsult}
                PatientsRegistered={PatientsRegistered}
              />
            }
          />

          <Route path="/editarConsulta/:id"
            element={
              <EditConsult
                proxConsult={proxConsult}
                previousConsult={previousConsult}
                updateConsult={updateConsult}
                deleteConsult={deleteConsult}
                PatientsRegistered={PatientsRegistered}
              />
            }
          />

          <Route path="/receta/:id" element={<RecipePDF previousConsult={previousConsult} />} />
        </Routes>
      </main>

    </>
  );
}

export default App;
