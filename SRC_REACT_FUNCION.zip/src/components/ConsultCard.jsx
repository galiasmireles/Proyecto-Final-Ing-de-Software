import React from 'react';
import { Link } from 'react-router-dom';
import '../css/ConsultCard.css';

function ConsultCard({ paciente, onDelete }) {
  const getTimeRemaining = (dateStr, timeStr) => {
    if (!dateStr || !timeStr) return "Fecha pendiente";
    const [day, month, year] = dateStr.split('/').map(n => parseInt(n, 10));
    const consultDate = new Date(year, month - 1, day);
    const [time, modifier] = timeStr.split(' ');
    let [hours, minutes] = time.split(':');
    if (hours === '12') hours = '00';
    if (modifier === 'PM') hours = parseInt(hours, 10) + 12;
    consultDate.setHours(parseInt(hours, 10), parseInt(minutes, 10), 0);
    const now = new Date();
    const diffMs = consultDate - now;
    if (diffMs < 0) return "Consulta Finalizada";
    const diffHrs = Math.floor((diffMs % 86400000) / 3600000);
    const diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffDays > 0) return `Faltan ${diffDays} días`;
    if (diffHrs > 0) return `Faltan ${diffHrs} hrs y ${diffMins} min`;
    return `Faltan ${diffMins} min`;
  };

  const renderDescription = () => {
    if (Array.isArray(paciente.motive)) {
      return (
        <ul className="motive-list">
          {paciente.motive.map((item, i) => <li key={i}>{item}</li>)}
        </ul>
      );
    }
    return <div className="description">{paciente.motive}</div>;
  };

  const timeString = getTimeRemaining(paciente.date, paciente.hour);
  const isUrgent = timeString.includes("min") && !timeString.includes("días");

  return (
    <div className="consult-card">
      <div className="card-header">
        <div>
          <h4 className="patient-name">{paciente.patient_name}</h4>
          <h5 style={{ color: isUrgent ? '#e32b1e' : '#666' }}>⏱ {timeString}</h5>
        </div>

        <div className="header-actions">
          <span className="status-label">Paciente de Seguimiento</span>
          <Link to={`/editarConsulta/${paciente.id}`} className="history-link">Editar Consulta</Link>
          <Link to="/historial" className="history-link">Visualizar Historial Médico</Link>
        </div>
      </div>

      <div className="card-body">
        <p><strong>Fecha: </strong>{paciente.date}</p>
        <p><strong>Hora: </strong>{paciente.hour}</p>
        <p><strong>Ubicación: </strong>{paciente.ubi}</p>

        <div className="info-block">
          <strong>Motivo: </strong>
          {renderDescription()}
        </div>

        <p><strong>Diagnóstico: </strong>{paciente.diagnostic || '-'}</p>
        <p><strong>Estudios: </strong>{paciente.medical_studies || '-'}</p>
        <p><strong>Seguimiento: </strong>{paciente.followup || '-'}</p>
      </div>

      <div className="card-footer">
        <button style={{ marginLeft: 8, background: '#e32b1e', border: '1px solid #ddd', padding: '8px 12px', color: 'white',borderRadius: 6 }} onClick={() => onDelete(paciente.id)}>Eliminar</button>
      </div>
    </div>
  );
}

export default ConsultCard;
