import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/ConsultCard.css';

function ConsultCardHistory({ paciente }) {
  const navigate = useNavigate();

  const renderMotive = () => {
    if (Array.isArray(paciente.motive)) {
      return (
        <ul className="motive-list">
          {paciente.motive.map((item, i) => <li key={i}>{item}</li>)}
        </ul>
      );
    }
    return <span className="text-normal">{paciente.motive}</span>;
  };

  return (
    <div className="consult-card">
      <div className="card-header">
        <h4 className="patient-name">{paciente.patient_name}</h4>
        <div className="header-actions">
          <span className="status-label">Paciente de Seguimiento</span>
          <Link to="/historial" className="history-link">Visualizar Historial Médico</Link>
        </div>
      </div>

      <div className="card-body">
        <p><strong>Fecha Consulta: </strong> {paciente.date}</p>
        <p><strong>Hora: </strong> {paciente.hour}</p>
        <p><strong>Ubicación: </strong> {paciente.ubi}</p>

        <div className="info-block">
          <strong>Motivo: </strong>
          {renderMotive()}
        </div>

        <p><strong>Diagnóstico: </strong> {paciente.diagnostic}</p>
        <p><strong>Estudios Solicitados: </strong>{paciente.medical_studies}</p>
        <p><strong>Seguimiento: </strong> {paciente.followup}</p>
      </div>

      <div className="card-footer">
        <button
          className="btn-receta"
          onClick={() => navigate(`/receta/${paciente.id}`, { state: { consulta: paciente } })}
        >
          Visualizar receta
        </button>
      </div>

    </div>
  );
}

export default ConsultCardHistory;
