import { Link } from 'react-router-dom';
import '../css/NavBar.css';

function NavBar() {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/" className="brand-link">
          <img src="/farmaciasbenavideslogo.png" alt="Logo Farmacias Benavides" className="logo-img" />
        </Link>
      </div>

      <div className="navbar-links">
        <Link to="/" className="nav-link">Categorías</Link>
        <Link to="/" className="nav-link">Benavides Conmigo</Link>
        <Link to="/" className="nav-link">Favoritos</Link>
        <div className="menu-icon">
          <svg viewBox="0 0 100 80" width="30" height="30" fill="#00205B">
            <rect width="100" height="10"></rect>
            <rect y="30" width="100" height="10"></rect>
            <rect y="60" width="100" height="10"></rect>
          </svg>
        </div>
      </div>
    </nav>
  );
}

export default NavBar;
