import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect, useMemo } from "react";
import { StaticDatePicker } from "@mui/x-date-pickers";
import Box from "@mui/material/Box";
import dayjs from "dayjs";
import '../css/EditConsults.css';
import '../css/DoctorConsults.css';

function EditConsult({ proxConsult, previousConsult, updateConsult, deleteConsult, PatientsRegistered }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const consultId = Number(id);

  const all = [...proxConsult, ...previousConsult];
  const found = all.find(c => c.id === consultId);

  const [patientName, setPatientName] = useState(found?.patient_name || "");
  const [date, setDate] = useState(found ? dayjs(found.date.split('/').reverse().join('-')) : dayjs());
  const [hour, setHour] = useState(found?.hour || "");
  const [motiveText, setMotiveText] = useState(
    Array.isArray(found?.motive) ? (found?.motive[0] || "") : (found?.motive || "")
  );

  const [searchRegistered, setSearchRegistered] = useState("");

  useEffect(() => {
    if (!found) navigate("/");
  }, [found]);

  // BUSCADOR filtrado
  const filteredPatients = useMemo(() => {
    const s = searchRegistered.trim().toLowerCase();
    if (!s) return [];
    return PatientsRegistered.filter(p =>
      p.patient_name.toLowerCase().includes(s)
    );
  }, [searchRegistered, PatientsRegistered]);

  const handleSave = () => {
    if (!patientName || !hour) {
      alert("Complete nombre y hora");
      return;
    }

    const updated = {
      ...found,
      patient_name: patientName,
      date: date.format("DD/MM/YYYY"),
      hour,
      motive: motiveText ? [motiveText] : []
    };

    updateConsult(updated);
    navigate("/");
  };

  const handleDelete = () => {
    if (confirm("¿Eliminar esta consulta?")) {
      deleteConsult(found.id);
      navigate("/");
    }
  };

  return (
    <div className="page-container">
      <div className="header-row">
        <h1 className="page-title">Editar Consulta</h1>
        <button className="btn-agendar" onClick={() => navigate("/")}>Volver</button>
      </div>

      <Box
        component="section"
        className="page-box"
        sx={{
          margin: "20px auto",
          padding: "22px",
          width: "900px",
          maxWidth: "95%"
        }}
      >
        <div className="modal-row top-section">
          <div className="date-picker-container">
            <div className="dp-wrapper">
              <StaticDatePicker value={date} onChange={(v) => setDate(v)} />
            </div>
          </div>

          <div className="available-hours">
            <button
              className={`hour-btn ${hour === "9:00 AM" ? "active" : ""}`}
              onClick={() => setHour("9:00 AM")}
            >
              9:00 AM
            </button>

            <button
              className={`hour-btn ${hour === "3:00 PM" ? "active" : ""}`}
              onClick={() => setHour("3:00 PM")}
            >
              3:00 PM
            </button>

            <div style={{ marginTop: 12 }}>
              <label>Otro (escribe):</label>
              <input className="modal-input" value={hour} onChange={(e) => setHour(e.target.value)} />
            </div>
          </div>
        </div>

        <div className="modal-row form-section" style={{ marginTop: 18 }}>
          <div className="form-column">
            <label>Nombre Paciente</label>
            <input
              className="modal-input"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
            />

            <label style={{ marginTop: 10 }}>Buscar en registrados</label>

            <div className="search-input-wrapper">
              <input
                className="modal-input"
                placeholder="Buscar paciente..."
                value={searchRegistered}
                onChange={(e) => setSearchRegistered(e.target.value)}
              />
            </div>

            {searchRegistered.trim() !== "" && (
              <div className="suggestions-box">
                {filteredPatients.length > 0 ? (
                  filteredPatients.map(p => (
                    <div
                      key={p.id}
                      className="suggestion-item"
                      onClick={() => {
                        setPatientName(p.patient_name);
                        setSearchRegistered("");
                      }}
                    >
                      {p.patient_name}
                    </div>
                  ))
                ) : (
                  <div className="no-results">Sin coincidencias</div>
                )}
              </div>
            )}
          </div>

          <div className="form-column column-right">
            <label>Motivo</label>
            <input
              className="modal-input"
              value={motiveText}
              onChange={(e) => setMotiveText(e.target.value)}
            />

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
              <button className="btn-confirmar" onClick={handleSave}>Guardar Cambios</button>
              <button style={{ background: '#ddd', borderRadius: 6, padding: '10px 16px', border: 'none', cursor: 'pointer' }} onClick={handleDelete}>Eliminar</button>
            </div>
          </div>
        </div>
      </Box>
    </div>
  );
}

export default EditConsult;
