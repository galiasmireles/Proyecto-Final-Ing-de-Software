import React, { useRef } from "react";
import { useParams, useLocation, useNavigate } from "react-router-dom";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import "../css/RecipePDF.css";

function RecipePDF({ previousConsult }) {
  const navigate = useNavigate();
  const { id } = useParams();
  const { state } = useLocation();
  const ref = useRef();

  // Si viene desde el botón
  let consulta = state?.consulta;

  // Si el usuario entra directo desde la URL /receta/:id
  if (!consulta) {
    consulta = previousConsult.find((c) => c.id === Number(id));
  }

  const receta = consulta?.receta;

  if (!receta)
    return (
      <div style={{ padding: 30 }}>
        No hay receta disponible.
        <br />
        <button onClick={() => navigate(-1)}>Volver</button>
      </div>
    );

  const descargarPDF = async () => {
    const canvas = await html2canvas(ref.current, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "pt",
      format: "a4",
    });

    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`receta_${consulta.patient_name.replace(/\s+/g, "_")}.pdf`);
  };

  return (
    <div className="pdf-page">
      <div className="top-actions">
        <button className="btn-back" onClick={() => navigate(-1)}>
          ← Volver
        </button>

        <button className="btn-imprimir" onClick={descargarPDF}>
          Descargar PDF
        </button>
      </div>

      <div className="pdf-card" ref={ref}>
  <h2>Receta Médica</h2>

  {/* Datos principales */}
  <p className="field-label">
    Nombre del Paciente:
    <span className="field-line">{receta.paciente}</span>
  </p>

  <p className="field-label">
    Nombre del Doctor:
    <span className="field-line">Dr. Andrés González</span>
  </p>

  <p className="field-label">
    Fecha:
    <span className="field-line">{receta.date}</span>
  </p>

  <p className="field-label">
    Hora:
    <span className="field-line">{receta.hour}</span>
  </p>

  <p className="doctor-id">Cédula de Doctor: 0123 4567 F89</p>

  <hr />

  <h3 style={{ marginTop: "20px" }}>Medicamentos</h3>

  {/* Medicamentos con formato de puntos y dos columnas */}
  {receta.medicamentos.map((m, i) => (
    <div key={i} className="medicine-block">
      
      <div className="medicine-line">
        Presentación
        <span className="medicine-dots"></span>
        {m.dosis}
      </div>

      <div className="medicine-line">
        {m.medicamento}
        <span className="medicine-dots"></span>
        {m.frecuencia}
      </div>
    </div>
  ))}

  <div className="signature">
    Firma del Doctor
    <div className="signature-line"></div>
  </div>
</div>

    </div>
  );
}

export default RecipePDF;
