import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import ConsultCard from "../components/ConsultCard";
import ConsultCardHistory from "../components/ConsultCardHistory";
import '../css/DoctorConsults.css';
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import { StaticDatePicker } from "@mui/x-date-pickers";
import dayjs from "dayjs";

function DoctorConsults({ proxConsult, previousConsult, addConsult, deleteConsult, PatientsRegistered }) {
  const [activeTab, setActiveTab] = useState('proximas');
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => {
    // limpiar campos al cerrar
    setNewDate(dayjs());
    setNewHour("");
    setNewPatient("");
    setNewMotive("");
    setIsBenavides(true);
    setSearchRegistered("");
    setOpen(false);
  };

  // Modal fields
  const [newDate, setNewDate] = useState(dayjs());
  const [newHour, setNewHour] = useState("");
  const [newPatient, setNewPatient] = useState("");
  const [newMotive, setNewMotive] = useState("");

  // Radio y buscador interno
  const [isBenavides, setIsBenavides] = useState(true);
  const [searchRegistered, setSearchRegistered] = useState("");

  // Buscador global
  const [searchTerm, setSearchTerm] = useState("");

  // Filtrado pacientes registrados (autocompletar)
  const filteredPatients = useMemo(() => {
    const s = searchRegistered.trim().toLowerCase();
    if (!s) return [];
    return PatientsRegistered.filter(p => p.patient_name.toLowerCase().includes(s));
  }, [searchRegistered, PatientsRegistered]);

  // Crear nueva consulta
  const setNewConsult = () => {
    if (!newPatient || !newHour || !newDate) {
      alert("Por favor completa Nombre, Fecha y Hora");
      return;
    }

    const newConsult = {
      id: Date.now(),
      patient_name: newPatient,
      date: newDate.format("DD/MM/YYYY"),
      hour: newHour,
      ubi: "Benavides Valle Alto",
      motive: newMotive ? [newMotive] : []
    };

    addConsult(newConsult);
    handleClose();
  };

  // Vistas y filtro global
  const consultView = activeTab === 'proximas' ? proxConsult : previousConsult;

  const filteredConsults = consultView.filter(c =>
    c.patient_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="header-row">
        <h1 className="page-title">Consultas</h1>

        <div className="header-actions">
          <button className="btn-agendar" onClick={handleOpen}>Agendar Nueva Consulta</button>

          <div className="search-wrapper">
            <input
              type="text"
              placeholder="Buscador"
              className="search-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <span className="search-icon">🔍</span>
          </div>
        </div>
      </div>

      <div className="tabs-row">
        <button
          className={`tab-btn ${activeTab === 'proximas' ? 'active' : ''}`}
          onClick={() => setActiveTab('proximas')}
        >
          Consultas Próximas
        </button>

        <button
          className={`tab-btn ${activeTab === 'anteriores' ? 'active' : ''}`}
          onClick={() => setActiveTab('anteriores')}
        >
          Consultas Anteriores
        </button>
      </div>

      <hr className="divider" />

      {/* Modal para nueva consulta */}
      <Modal open={open} onClose={handleClose}>
        <Box className="box">
          <h2 className="modal-title">Nueva Consulta</h2>

          <div className="modal-body">

            <div className="modal-row top-section">
              <div className="date-picker-container">
                <StaticDatePicker
                  value={newDate}
                  onChange={(value) => setNewDate(value)}
                />
              </div>

              <div className="available-hours">
                <button
                  className={`hour-btn ${newHour === "9:00 AM" ? "active" : ""}`}
                  onClick={() => setNewHour("9:00 AM")}
                >
                  9:00 AM
                </button>

                <button
                  className={`hour-btn ${newHour === "3:00 PM" ? "active" : ""}`}
                  onClick={() => setNewHour("3:00 PM")}
                >
                  3:00 PM
                </button>
              </div>
            </div>

            <div className="modal-row form-section">
              <div className="form-column">
                <h4>Paciente</h4>

                <div className="input-group">
                  <label>Nombre Paciente</label>
                  <input type="text" className="modal-input" value={newPatient} onChange={(e) => setNewPatient(e.target.value)} required />
                </div>

                <div className="input-group checkbox-group">
                  <label>¿Ya es paciente de Benavides?</label>
                  <div>
                    <input
                      type="radio"
                      name="benavides"
                      checked={isBenavides === true}
                      onChange={() => setIsBenavides(true)}
                    />
                    <label style={{ marginRight: 10 }}>Si</label>

                    <input
                      type="radio"
                      name="benavides"
                      checked={isBenavides === false}
                      onChange={() => setIsBenavides(false)}
                    />
                    <label>No</label>
                  </div>
                </div>

                {isBenavides && (
                  <div className="input-group">
                    <label>Buscar Usuario</label>
                    <div className="search-input-wrapper">
                      <input
                        type="text"
                        className="modal-input"
                        placeholder="Buscar..."
                        value={searchRegistered}
                        onChange={(e) => setSearchRegistered(e.target.value)}
                      />
                      <span>🔍</span>
                    </div>

                    {searchRegistered.trim().length > 0 && (
                      <div className="suggestions-box">
                        {filteredPatients.length > 0 ? filteredPatients.map(p => (
                          <div
                            key={p.id}
                            className="suggestion-item"
                            onClick={() => {
                              setNewPatient(p.patient_name);
                              setSearchRegistered("");
                            }}
                          >
                            {p.patient_name}
                          </div>
                        )) : (
                          <div className="no-results">Sin coincidencias</div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="form-column column-right">
                <h4>Motivo</h4>
                <div className="input-group">
                  <label>Motivo consulta</label>
                  <input type="text"
                    className="modal-input"
                    value={newMotive}
                    onChange={(e) => setNewMotive(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
            <button className="btn-confirmar" onClick={setNewConsult}>
              Confirmar
            </button>
          </div>
        </Box>
      </Modal>

      <div className="consults-grid">
        {filteredConsults.length === 0 && (
          <div style={{ gridColumn: '1 / -1', color: '#666' }}>No hay consultas que coincidan.</div>
        )}

        {filteredConsults.map((paciente) => (
          activeTab === 'proximas'
            ? <ConsultCard key={paciente.id} paciente={paciente} onDelete={deleteConsult} />
            : <ConsultCardHistory key={paciente.id} paciente={paciente} />
        ))}
      </div>
    </div>
  )
}

export default DoctorConsults;
